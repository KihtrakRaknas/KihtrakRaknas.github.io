self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e8b9d9290b34ec26c9403d90f7e27db3",
    "url": "/index.html"
  },
  {
    "revision": "4afc8d7ffe9897a24202",
    "url": "/static/css/main.e0134b25.chunk.css"
  },
  {
    "revision": "4389ad4033f3e6b512f2",
    "url": "/static/js/2.02aef465.chunk.js"
  },
  {
    "revision": "7a89e3d281fa9635a295233480825c89",
    "url": "/static/js/2.02aef465.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4afc8d7ffe9897a24202",
    "url": "/static/js/main.3b72db03.chunk.js"
  },
  {
    "revision": "da53d9dbd97741c1b847",
    "url": "/static/js/runtime-main.c159b9bc.js"
  },
  {
    "revision": "3b868257c95029a83bc34739750de680",
    "url": "/static/media/3dShooter.3b868257.webp"
  },
  {
    "revision": "8d452b1c1a2a75ee8136ddc543358ee8",
    "url": "/static/media/750SSite.8d452b1c.webp"
  },
  {
    "revision": "321df6c016101ba54dceae9b8d5fe0c2",
    "url": "/static/media/ActualTrash.321df6c0.webp"
  },
  {
    "revision": "1b65926236d951b2af57201b275f595b",
    "url": "/static/media/App_Store_Badge.1b659262.svg"
  },
  {
    "revision": "bd24632ee61a20fa4235bdc372bc4a88",
    "url": "/static/media/Karthik-compressed.bd24632e.webp"
  },
  {
    "revision": "e766e05a06ad4e3d9fb0b6d011d0ff09",
    "url": "/static/media/Karthik-headshot-2022-256.e766e05a.webp"
  },
  {
    "revision": "a386b8849edb38fb5b4417dae9d2b0d2",
    "url": "/static/media/NHSStaffFeedback.a386b884.webp"
  },
  {
    "revision": "844021077fcbc2fe733d60d69a70b05b",
    "url": "/static/media/NotiBot.84402107.webp"
  },
  {
    "revision": "aa8883fb9a27b728a471dd0172354b33",
    "url": "/static/media/POPs.aa8883fb.webp"
  },
  {
    "revision": "096b842bece774d7d9fa57af73bc09be",
    "url": "/static/media/TubeCreation.096b842b.webp"
  },
  {
    "revision": "9c11ebfea6ad37d45d2114aa139b81ae",
    "url": "/static/media/aLackOfClarity.9c11ebfe.webp"
  },
  {
    "revision": "30ba0fe5ba10ed1e85d054c7e4a9dc66",
    "url": "/static/media/calculator.30ba0fe5.webp"
  },
  {
    "revision": "770692b23f9901cddefb4b33f917f07a",
    "url": "/static/media/cannon.770692b2.webp"
  },
  {
    "revision": "291eccc8761be84c5040d0b9d7572af4",
    "url": "/static/media/favicon.291eccc8.ico"
  },
  {
    "revision": "b3775485a1689e76cacce3821fcc1ef1",
    "url": "/static/media/goldbelt.b3775485.webp"
  },
  {
    "revision": "980369148521cb4f0a42a2dfd192d65b",
    "url": "/static/media/gradeView.98036914.webp"
  },
  {
    "revision": "90ef449388262f1991af7169ed3ca133",
    "url": "/static/media/maze.90ef4493.webp"
  },
  {
    "revision": "0af10880f00f85c6d3f88d05b7ad71c4",
    "url": "/static/media/mrPoot.0af10880.webp"
  },
  {
    "revision": "8e99179e27c31a04369c3dcc660ccb81",
    "url": "/static/media/multiPong.8e99179e.webp"
  },
  {
    "revision": "9ab99c34c84c71f086db60f4e54ce778",
    "url": "/static/media/myAwesomeStudio.9ab99c34.webp"
  },
  {
    "revision": "9b46d10f94257a01d95a8a25642cc877",
    "url": "/static/media/newRoboticsPortfolio.9b46d10f.webp"
  },
  {
    "revision": "7a62fded675ca92c6cb3faf53e4bdc4a",
    "url": "/static/media/ninjaBucks.7a62fded.webp"
  },
  {
    "revision": "00584fd421a58d0a9a7aeb6a3d93336f",
    "url": "/static/media/ninjaEvaluation.00584fd4.webp"
  },
  {
    "revision": "4baa68bf65b8686139305b5b870f8374",
    "url": "/static/media/oldRoboticsPortfolio.4baa68bf.webp"
  },
  {
    "revision": "7c32747da5868239b3f802431a9ce903",
    "url": "/static/media/potatoes.7c32747d.webp"
  },
  {
    "revision": "184794a0e4ef7698d092a098d0eaf1a6",
    "url": "/static/media/red.184794a0.webp"
  },
  {
    "revision": "810505c3b5169c749a9c553ec0dd396d",
    "url": "/static/media/scoutr.810505c3.webp"
  },
  {
    "revision": "d9f4e19d14b552d7d77fc4e3b86ea737",
    "url": "/static/media/setup.d9f4e19d.webp"
  },
  {
    "revision": "cae8fb5fc149e8be13b96a9d621bea02",
    "url": "/static/media/smartBottle.cae8fb5f.webp"
  },
  {
    "revision": "f8f9f736e244ac62c6078f5b947b84af",
    "url": "/static/media/starFox.f8f9f736.webp"
  },
  {
    "revision": "89e5a2bd42eea488a46fd21a34a39887",
    "url": "/static/media/topDownShooter.89e5a2bd.webp"
  }
]);